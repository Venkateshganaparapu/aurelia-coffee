import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

# Desktop
opts = Options()
opts.add_argument('--headless=new')
opts.add_argument('--window-size=1440,1200')
opts.add_argument('--disable-gpu')
opts.add_argument('--no-sandbox')

driver = webdriver.Chrome(options=opts)
try:
    driver.get('http://localhost:8080')
    time.sleep(2.0)
    
    # Scroll to top of journal
    driver.execute_script('document.getElementById("journal").scrollIntoView();')
    time.sleep(1.0)
    driver.save_screenshot('scratch/test_screenshots/journal_desktop_top.png')

    # Scroll down 400px to see the middle/bottom of journal
    driver.execute_script('window.scrollBy(0, 450);')
    time.sleep(0.8)
    driver.save_screenshot('scratch/test_screenshots/journal_desktop_bottom.png')
finally:
    driver.quit()

# Mobile
m_opts = Options()
m_opts.add_argument('--headless=new')
m_opts.add_argument('--window-size=390,844')
m_opts.add_argument('--disable-gpu')
m_opts.add_argument('--no-sandbox')

driver_m = webdriver.Chrome(options=m_opts)
try:
    driver_m.get('http://localhost:8080')
    time.sleep(2.0)
    driver_m.execute_script('document.getElementById("journal").scrollIntoView();')
    time.sleep(1.0)
    driver_m.save_screenshot('scratch/test_screenshots/journal_mobile_top.png')

    driver_m.execute_script('window.scrollBy(0, 700);')
    time.sleep(0.8)
    driver_m.save_screenshot('scratch/test_screenshots/journal_mobile_articles.png')

    driver_m.execute_script('window.scrollBy(0, 600);')
    time.sleep(0.8)
    driver_m.save_screenshot('scratch/test_screenshots/journal_mobile_video.png')
finally:
    driver_m.quit()

print("All screenshots taken successfully!")
