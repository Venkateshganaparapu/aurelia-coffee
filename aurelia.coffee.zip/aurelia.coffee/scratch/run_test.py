import time
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

os.makedirs('scratch/test_screenshots', exist_ok=True)
os.makedirs('scratch/mobile_screenshots', exist_ok=True)

# 1. Desktop Test
opts = Options()
opts.add_argument('--headless=new')
opts.add_argument('--window-size=1440,960')
opts.add_argument('--disable-gpu')
opts.add_argument('--no-sandbox')

driver = webdriver.Chrome(options=opts)
try:
    print('Testing Desktop 1440x960 ...')
    driver.get('http://localhost:8080')
    time.sleep(2.5) # wait for entrance screen
    
    driver.save_screenshot('scratch/test_screenshots/01_hero_desktop.png')
    print('Saved 01_hero_desktop.png')

    # Scroll to light chapter
    driver.execute_script('document.getElementById("sourcing").scrollIntoView();')
    time.sleep(1.0)
    driver.save_screenshot('scratch/test_screenshots/04_light_steps.png')

    # Scroll to craft
    driver.execute_script('document.getElementById("craft").scrollIntoView();')
    time.sleep(1.0)
    driver.save_screenshot('scratch/test_screenshots/06_dark_craft.png')

    # Scroll to collection
    driver.execute_script('document.getElementById("collection").scrollIntoView();')
    time.sleep(1.0)
    driver.save_screenshot('scratch/test_screenshots/07_collection_cards.png')

finally:
    driver.quit()

# 2. Mobile Test (375x812 - iPhone)
mobile_opts = Options()
mobile_opts.add_argument('--headless=new')
mobile_opts.add_argument('--window-size=375,812')
mobile_opts.add_argument('--disable-gpu')
mobile_opts.add_argument('--no-sandbox')

driver_m = webdriver.Chrome(options=mobile_opts)
try:
    print('Testing Mobile 375x812 ...')
    driver_m.get('http://localhost:8080')
    time.sleep(2.5)
    
    driver_m.save_screenshot('scratch/mobile_screenshots/m_01_hero.png')
    print('Saved m_01_hero.png')

    driver_m.execute_script('document.getElementById("sourcing").scrollIntoView();')
    time.sleep(1.0)
    driver_m.save_screenshot('scratch/mobile_screenshots/m_02_sourcing.png')
    print('Saved m_02_sourcing.png')

    driver_m.execute_script('document.getElementById("craft").scrollIntoView();')
    time.sleep(1.0)
    driver_m.save_screenshot('scratch/mobile_screenshots/m_03_craft.png')
    print('Saved m_03_craft.png')

    driver_m.execute_script('document.getElementById("collection").scrollIntoView();')
    time.sleep(1.0)
    driver_m.save_screenshot('scratch/mobile_screenshots/m_04_collection.png')
    print('Saved m_04_collection.png')

    driver_m.execute_script('window.scrollTo(0, document.body.scrollHeight);')
    time.sleep(1.0)
    driver_m.save_screenshot('scratch/mobile_screenshots/m_05_footer.png')
    print('Saved m_05_footer.png')

finally:
    driver_m.quit()

print('All desktop and mobile tests completed successfully!')
